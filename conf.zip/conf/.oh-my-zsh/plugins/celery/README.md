# Celery

This plugin provides completion for [Celery](http://www.celeryproject.org/).

To use it add celery to the plugins array in your zshrc file.

```bash
plugins=(... celery)
```
